/**
 * App 公共接口文件
 */
(function(win, undefined){
    "use strict";

    var AppOs, AppName = null,
        AppiOS = false, AppAndroid = false;

    //调用 App 查询接口 e.g Cmpay|ios AppName|DeviceName
    if (typeof(getDevice) === 'function') {
        AppOs = getDevice();
    }else if(typeof(sys) !== 'undefined' && typeof(sys.getDevice) === 'function') {
        AppOs = sys.getDevice();
    }else if(typeof(js2java) !== 'undefined' && typeof(js2java.hebaohjbdevice) === 'function') { // 和包 APP
        AppOs = js2java.hebaohjbdevice();
    }

    AppOs = AppOs ? AppOs.split('|') : '';

    if (AppOs[1]) {
        AppName = AppOs[0];
        if (/ios/i.test(AppOs[1])){
            AppiOS = true;
        }else if(/android/i.test(AppOs[1])){
            AppAndroid = true;
        }
    }

    win.BW_isAPP = {
        name : AppName,
        iOS : AppiOS,
        Android : AppAndroid,
        cmpay : /\b(cmpay)\b/i.test(AppName) ? true : false
    };

    win.APP_changeUser = function(type){ // 手势密码 更换用户
        if (BW_isAPP.Android) { // Android 需要回调
            sys.getShareMsg(data);
            return false;
        }
    };

}(window));