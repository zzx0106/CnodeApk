/**
 * [获取用户信息]
 */
var readUserInfo = (function (win, undefined) {
    "use strict";

    var locationURI = win.location.href,
        option, makeDeferred = $.Deferred();

    var requestLoginInit = function (callback) {    // 登录初始化
            var data = {}, api = globalConfig.httpPath + 'usr/urm/v1/loginInit.do';
            $.ajax({
                url: api,
                data: BW_API.reqEnjson(data),
                contentType: 'application/json',
                dataType: 'json',
                type: 'post',
                timeout: globalConfig.timeout,
                global: true
            }).done(function (ajaxData, status, xhr) {
                ajaxData = BW_API.resDejson(ajaxData);
                //console.log(ajaxData);
                if (ajaxData.rspCd === '00000') {
                    BW.tokenId.set({
                        tokenId: ajaxData.tokenId,
                        usrNo: ajaxData.usrNo
                    });
                    //缓存手机号码
                    // localStorage.setItem('usrTel', $('#login-tel').val());
                    localStorage.setItem('usrTel', ajaxData.mblNo);
                    setCache(ajaxData);
                    callback && callback(ajaxData);
                    makeDeferred.resolve();
                } else { // FUN03157 未登录  U0005 登记TOKEN信息失败
                    if (ajaxData.rspCd === 'FUN03149') {
                        gotoLogin();
                    }
                    if (ajaxData.rspCd !== 'FUN03157') {
                        BW.Toast(ajaxData.rspInf);
                        readUserInfo.clearLoginCache();
                    }
                    callback && callback(ajaxData);
                    makeDeferred.reject();
                }
            }).fail(function (XMLHttpRequest, textStatus, errorThrown) {
                makeDeferred.reject();
            });
        },
        setCache = function (data) {
            if (BW.canUseStorage()) {
                BW.uStore().remove(BW.STORE_USERINFO);
                delete data.userName;  // 去除未脱敏信息
                delete data.userRealName;
                delete data.idNo;
                delete data.mblNo;
                BW.uStore().set(BW.STORE_USERINFO, data);
            }
            checkPayPwdSts(data);
        },
        getCache = function (op) {      // 从缓存获取
            var dtd = $.Deferred(),
                getFLG = false,      // 是否从缓存读取成功
                setChannel;

            var getLoginStorage = function () {
                if (BW.canUseStorage()) {
                    setChannel = 'Storage';
                    var storageUserinfo = BW.uStore().get(BW.STORE_USERINFO);
                    if (storageUserinfo && storageUserinfo.rspCd === '00000') {
                        checkPayPwdSts(storageUserinfo);
                        getFLG = true;
                    }
                    dtd.resolve();
                }
                return dtd.promise();
            };
            $.when(getLoginStorage()).done(function () {
                if (getFLG) {
                    makeDeferred.resolve();
                } else {
                    //console.log(op);
                    if (op.needLogin) {
                        makeDeferred.reject();
                        gotoLogin();
                    } else {
                        requestLoginInit();
                    }
                }
            });
        },
        gotoLogin = function (uri) {      // 跳转登录页面
            uri = uri || 'login.html';

            var currentLink = new Uri(location.href), tmpLink = '',
                gotoURI = globalConfig.statichttpPath + uri;

            if (currentLink.path().toString().indexOf(uri) !== -1) {
                tmpLink = '';
                return false;
            } else {
                // 忘记是干什么的了. Mice
                // else if(currentLink.path().toString().indexOf('user-center.html') !== -1){
                //     tmpLink = '';
                // }
                if (option.appointLink) {
                    tmpLink = '?goto=' + option.appointLink;
                } else {
                    if (currentLink.hasQueryParam('goto')) {
                        tmpLink = '?goto=' + encodeURIComponent(currentLink.getQueryParamValue('goto').toString());
                    } else {
                        tmpLink = '?goto=' + encodeURIComponent(currentLink.toString());
                    }
                }
            }

            location.href = gotoURI + tmpLink; //replace
            return false;
        },
        //2016 12.9  9:40   判断去活动页
        checkPayPwdSts = function (data) {  // 检测支付密码状态 0：正常；1：锁定；2：初始化状态
            if (data && data.payPwdSts === '2') {
                gotoLogin('set_pay_pwd.html');
            }
        };

    return {
        init: function (options) { // 初始化
            var self = this,
                defaults = {
                    needLogin: false     // 是否需要强制登录
                },
                opts = $.extend({}, defaults, options || {});
            option = opts;

            getCache(option);

            return makeDeferred.promise();
        },
        loginInit: function (callback) { // 登录后初始化
            requestLoginInit(callback);
            return makeDeferred.promise();
        },
        clearLoginCache: function (uri) {  // 清除本地登录信息缓存 (uri === notjump 不做跳转处理)
            BW.uStore().remove(BW.STORE_USERINFO);
            BW.uStore().remove(BW.STORE_USERTOKEN);
            if (uri !== 'notjump') {
                gotoLogin(uri);
            }
        }
    }
}(window));