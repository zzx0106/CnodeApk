// 调试开关，true为log信息输出模式，false为关闭log信息
var _debug = {
    debug: false
};
var _hjbProtocol = document.location.origin;
var globalConfig = {
    httpPath: _hjbProtocol + '/',
    statichttpPath: _hjbProtocol + '/usr/',  //生产环境目录
    riskhttpPath: _hjbProtocol + '/usr/template/Agreement/riskTip/', //风险协议地址
    // riskhttpPath: _hjbProtocol + '/kayakHjb/kayakHjb/usr/template/Agreement/riskTip/', //风险协议地址
    // statichttpPath: _hjbProtocol + '/kayakHjb/kayakHjb/usr/',  //UAT目录
    cdnFiletime: '?v=20170530',
    timeout: '120000', // Ajax 请求超时时限
    rspExTime: '90' // 验证码倒计
};