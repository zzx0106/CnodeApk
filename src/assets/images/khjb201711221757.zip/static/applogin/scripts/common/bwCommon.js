(function (win, undefined) {
    "use strict";

    win.BW_TEST = win.BW_TEST || {};

    var BW = {
        // 全局goto匹配白名单
        gotoFilter: ['../transferMarket/transferMarket.html', '../../index.html', 'index.html'],
        STORE_USERINFO: 'userinfo',
        STORE_USERTOKEN: 'usertoken',
        STORE_APPCLIENTINFO: "appClientinfo",
        canUseStorage: function () {
            return !!win.sessionStorage;
        },
        canUseCookie: function () {
            return win.navigator.cookieEnabled;
        },
        Toast: function (msg, type, placement) {
            if (!msg) {
                return false;
            }
            type = type || 'default';
            placement = placement || 'center';
            $.zui.messager.show(msg, {type: type, placement: placement});
        },
        returnZero: function (obj) {
            return obj ? obj : 0;
        },
        formatMoney: function (num) { // 金钱格式化
            return accounting.formatMoney(new BigNumber(num).toFixed(2, 1), "", 2);
        },
        addObject: function (otherData, baseData) {
            var Data, tempData = JSON.parse(JSON.stringify(baseData));
            var extend = function (destination, source) {
                for (var property in source)
                    destination[property] = source[property];
                return destination;
            };
            Data = extend(tempData, otherData);
            return Data;
        },
        loadingModel: function (type, act) {

            if (!type || (type !== 'data' && type !== 'page')) {
                throw new Error('没输入正确 Loading 类型!');
            }

            act = act || 'toggle';

            var htmlstr = ['<div class="modal modal-noborder loading-modal loading-modal-page">',
                    '<div class="modal-dialog">',
                    '<div class="loader-model">',
                    '<i class="loader-icon"></i>',
                    '<div class="loader-inner ball-pulse"><div></div><div></div><div></div></div>',
                    '</div>',
                    '</div>',
                    '</div>'].join(''),
                option = {
                    keyboard: false,
                    backdrop: 'static',
                    show: false
                };

            if (!$('.loading-modal').length) {
                $('body').append(htmlstr);
            }

            var $loadingModal = $('.loading-modal');

            if (type !== 'data') {
                option.backdrop = false;
                $loadingModal.addClass('loading-modal-page');
            } else {
                $loadingModal.removeClass('loading-modal-page');
            }

            if ($loadingModal.data('zui.modal') && $loadingModal.data('zui.modal').options.backdrop !== option.backdrop) {
                $loadingModal.data('zui.modal', '');
            }

            $loadingModal.modal(option).modal(act);
        },
        hideLoadingPage: function () {
            $('body').removeClass('modal-open');
            $('.first-loading-page').remove();
        },
        hideTelNum: function (telnum) { // 脱敏手机号
            telnum = telnum || '';
            return telnum.replace(/(\d{3})\d{4}(\d{4})/, '$1****$2');
        },
        hideIdCard: function (cardnum) { // 脱敏身份证
            var cardEXP;
            cardnum = cardnum || '';
            switch (cardnum.length) {
                case 15:
                    //cardEXP = /(\d{6})\d{6}(\w{3})/;
                    cardEXP = /(\d{1})\d{13}(\w{1})/;
                    cardnum = cardnum.replace(cardEXP, '$1*************$2');
                    break;
                case 18:
                    //cardEXP = /(\d{8})\d{6}(\w{4})/;
                    cardEXP = /(\d{1})\d{16}(\w{1})/;
                    cardnum = cardnum.replace(cardEXP, '$1****************$2');
                    break;
            }
            return cardnum;
        },
        hideFullName: function (fullname) { // 脱敏姓名
            fullname = fullname || '';
            return new Array(fullname.length).join('*') + fullname.substr(-1);
        },
        getBankClass: function (name, size) { // 获取银行图标
            name = name ? name.toLowerCase() : name;
            size = size === 'small' ? size : 'big';
            return name ? (' bw-bank-comm-' + size + '-icon') + ' bw-bank-' + name + '-' + size + '-ico' : '';
        },
        PWstrength: function (s) { // 简单检查密码
            if (!/^\d{6}$/.test(s)) return false; // 不是6位数字
            if (/^(\d)\1+$/.test(s)) return false;  // 全一样

            var str = s.replace(/\d/g, function ($0, pos) {
                return parseInt($0) - pos;
            });
            if (/^(\d)\1+$/.test(str)) return false;  // 顺增

            str = s.replace(/\d/g, function ($0, pos) {
                return parseInt($0) + pos;
            });
            if (/^(\d)\1+$/.test(str)) return false;  // 顺减
            return true;
        },
        retTermId: function () { // 获取终端号termId
            if (BW_isAPP.iOS) {
                return getTermId();
            } else if (BW_isAPP.Android && typeof(sys) !== 'undefined' && typeof(sys.getTermId) === 'function') {
                return sys.getTermId();
            } else {
                return "356056035101965";
            }
        },

        /**
         * [全局的页面跳转方法]
         * Created zuohx 2017年02月09日11:02:59.
         * 从登录页跳转时都应该带有域名
         * 如果条件匹配的话则跳转到页面
         * 否则默认跳转到首页
         */
        loginToLocation: function (url) {
            if (_debug.debug) {
                if (url) {
                    location.replace(decodeURIComponent(url));
                } else {
                    location.replace(globalConfig.statichttpPath + 'index.html');
                }
            } else {
                if (decodeURIComponent(url).indexOf('cmf.cmpay.com') != -1) {
                    location.replace(decodeURIComponent(url));
                } else {
                    location.replace(globalConfig.statichttpPath + 'index.html');
                }

                // if (decodeURIComponent(url).indexOf('172.16.49.61') != -1) {
                //     location.replace(decodeURIComponent(url));
                // } else {
                //     location.replace(globalConfig.statichttpPath + 'index.html');
                // }
            }
        },

        /** 
         * [年月日格式化] 
         * Created zuohx 2016年01月21日14:59:16. 
         * @param  {[type]} 'FormatToDate'           [传入时间字符串] 
         * @param  {[String]} function (){}          [需要格式化的日期字符串, 时间分隔符('/', '-')] 
         * @return {[String]}                        [日期字符串(年月日)] 
         */
        FormatToDate: function (str, type) {
            if (typeof str == 'undefined' || str == null || str == "") {
                return "";
            }
            if (type) {
                return str.substr(0, 4) + type + str.substr(4, 2) + type + str.substr(6, 2);
            } else {
                return str.substr(0, 4) + "/" + str.substr(4, 2) + "/" + str.substr(6, 2);
            }
        },

        /**
         * 格式化数字，保留2位小数，如：2，会在2后面补上00.即2.00
         * Created zuohx 2017年1月10日20:59:33.
         * @param x
         * @returns {*}
         */
        toDecimal2: function (x) {
            var f = parseFloat(x);
            if (isNaN(f)) {
                return false;
            }
            var f = Math.round(x * 100) / 100;
            var s = f.toString();
            var rs = s.indexOf('.');
            if (rs < 0) {
                rs = s.length;
                s += '.';
            }
            while (s.length <= rs + 2) {
                s += '0';
            }
            return s;
        },

        /**
         * 获取用户IP地址
         */
        getIp: function (callback) {
            head.js("http://pv.sohu.com/cityjson?ie=utf-8", function () {
                var ip = returnCitySN["cip"];
                if (_debug.debug) {
                    console.log(returnCitySN["cip"]);
                }
                callback && callback(ip);
            })
        },

        /**
         * 获取系统信息
         */
        getSystemOS: function () {
            //平台、设备和操作系统
            var system = {
                win: false,
                mac: false,
                xll: false,
                android: false,
                iPhone: false,
                ipad: false
            };
            //检测平台
            var p = navigator.platform,
                u = navigator.userAgent;
            system.win = p.indexOf("Win") == 0;
            system.mac = p.indexOf("Mac") == 0;
            // system.x11 = (p == "X11") || (p.indexOf("Linux") == 0);
            system.android = u.indexOf('Android') > -1 || u.indexOf('Linux') > -1; //android终端或者uc浏览器
            system.iPhone = u.indexOf('iPhone') > -1 || u.indexOf('Mac') > -1; //是否为iPhone或者QQHD浏览器
            system.ipad = (navigator.userAgent.match(/iPad/i) != null) ? true : false;


            //跳转语句，如果是手机访问就自动跳转到wap.baidu.com页面
            if (system.win || system.mac) {
                return '00';   // 电脑
            } else if (system.android || system.iPhone) {
                return '01';   // 手机
            } else if (system.ipad) {
                return '02';   // 平板设备
            } else {
                return '99';   // 其他
            }

            // var u = navigator.userAgent, app = navigator.appVersion;
            // return {
            //     trident: u.indexOf('Trident') > -1, //IE内核
            //     presto: u.indexOf('Presto') > -1, //opera内核
            //     webKit: u.indexOf('AppleWebKit') > -1, //苹果、谷歌内核
            //     gecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') == -1, //火狐内核
            //     mobile: !!u.match(/AppleWebKit.*Mobile.*/) || !!u.match(/AppleWebKit/), //是否为移动终端
            //     ios: !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/), //ios终端
            //     android: u.indexOf('Android') > -1 || u.indexOf('Linux') > -1, //android终端或者uc浏览器
            //     iPhone: u.indexOf('iPhone') > -1 || u.indexOf('Mac') > -1, //是否为iPhone或者QQHD浏览器
            //     iPad: u.indexOf('iPad') > -1, //是否iPad
            //     webApp: u.indexOf('Safari') == -1 //是否web应该程序，没有头部与底部
            // };

            // document.writeln(" 是否为移动终端: "+browser.versions.mobile);
            // document.writeln(" ios终端: "+browser.versions.ios);
            // document.writeln(" android终端: "+browser.versions.android);
            // document.writeln(" 是否为iPhone: "+browser.versions.iPhone);
            // document.writeln(" 是否iPad: "+browser.versions.iPad);
            // document.writeln(navigator.userAgent);
        },

        /**
         * 调用密码组件方法
         *
         * @param dom               // 需要监听的DOM
         * @param isRandom          // 是否生成随机键盘
         * @param isShowRealValue   // 控件是否显示真实值
         * @param maxLength         // 值的长度
         * @returns {Window.pwdKeyBoard}
         */
        pwdKeyBoard: function (obj) {
            var dom = obj.dom,
                isRandom = obj.isRandom,
                isShowRealValue = obj.isShowRealValue,
                maxLength = obj.maxLength;

            if (!dom) {
                console.log('请传入输入框DOM节点');
                return false;
            }
            return new pwdKeyBoard(dom, isRandom | false, isShowRealValue | true, maxLength | 6);
        }

    };


    BW.ajaxComm = function (commData, callback) {
        if (_debug.debug) {
            console.debug("上送参数：", commData.reqData);
        }
        var api = globalConfig.httpPath + commData.reqUrl;
        $.ajax({
            url: api,
            data: BW_API.reqEnjson(commData.reqData),
            contentType: 'application/json',
            dataType: 'json',
            type: 'post',
            timeout: globalConfig.timeout,
            global: true,
            beforeSend: function () {
                BW.loadingModel('data', 'show');
            }
        }).done(function (ajaxData, status, xhr) {
            ajaxData = BW_API.resDejson(ajaxData);
            if (_debug.debug) {
                console.debug("接受返回：" + api + ' ', ajaxData);
            }
            callback && callback(ajaxData);
            BW.loadingModel('data', 'hide');
        }).fail(function (XMLHttpRequest, textStatus, errorThrown) {
            BW.Toast('服务器忙，请稍后再试');
            BW.loadingModel('data', 'hide');
        });
    };

    // Ajax LocalCache
    BW.AjaxLocalCache = {
        /**
         * timeout for cache in millis
         * @type {number}
         */
        timeout: 30000,
        removeAll: function () {
            store.each(function (name, data) {
                if (/^(http|https):\/\/.*\.do/.test(name)) {
                    store.remove(name);
                }
            });
        },
        remove: function (url) {
            store.remove(url);
        },
        exist: function (url) {
            return !!store(url);
            // return !!localCache.data[url] && ((new Date().getTime() - localCache.data[url]._) < localCache.timeout);
        },
        get: function (url) {
            // console.log('Getting in cache for url' + url);
            return store(url);
        },
        getData: function (url) {
            // console.log('Getting in cache for url' + url);
            return store(url).data;
        },
        set: function (url, cachedTime, cachedData, callback) {
            store.remove(url);
            store(url, {
                _: cachedTime ? cachedTime : parseInt(new Date().getTime() / 1000, 10) + '',
                data: cachedData
            });
            if ($.isFunction(callback)) {
                callback(cachedData);
            }
        }
    };

    $.ajaxPrefilter(function (options, originalOptions, jqXHR) {
        if (options.localcache) {
            var id = originalOptions.url;
            options.localcache = false;
            if (!BW.AjaxLocalCache.exist(id)) {
                if (options.success) {
                    options.realsuccess = options.success;
                }
                options.success = function (data, status, jqXHR) {
                    BW.AjaxLocalCache.set(id, BW_API.resDejson(data).cacheTime, data);

                    if (options.realsuccess) {
                        options.realsuccess(data, status, jqXHR);
                    }
                };
            }

        }
    });

    $.ajaxTransport('json', function (options, originalOptions, jqXHR) {

        // same here, careful because options.url has already been through jQuery processing
        var id = originalOptions.url;

        options.localcache = false;

        if (BW.AjaxLocalCache.exist(id)) {
            return {
                send: function (headers, completeCallback) {
                    completeCallback(200, 'success', {json: BW.AjaxLocalCache.getData(id)});
                },
                abort: function () {
                    /* abort code, nothing needed here I guess... */
                }
            };
        }
    });

    // 获取浏览器信息
    BW.getBrowser = (function () {
        var nav = win.navigator,
            ua = nav.userAgent.toLowerCase();

        ua = /(iphone|ipad|ipod)(?:.*version)?[ \/]([\w.]+)/.exec(ua) || // Mobile IOS
            /(android)(?:.*version)?[ \/]([\w.]+)/.exec(ua) || []; // Mobile Webkit

        var browser = ua[1],
            version = ua[2];

        switch (browser) {
            case "ipod":
                browser = "ipod";
                break;
            case "ipad":
                browser = "ipad";
                break;
            case "iphone":
                browser = "iphone";
                break;
        }

        return {
            browser: browser ? browser.toUpperCase() : browser,
            version: version || '9.0',
            isWeixin: /MicroMessenger/gi.test(nav.userAgent)
        }
    }());

    BW.useSkin = (function () { // 是否修改颜色
        var cfg = {
            blue: {
                regexp: 'cmpay',
                fileuri: 'styles/home/blue/common.css'
            }
        };

        function check() {
            var tempArr = false;
            $.each(cfg, function (i, item) {
                var reg = new RegExp("\\b(" + item.regexp + ")\\b", "i");
                if (reg.test(BW_isAPP.name)) {
                    tempArr = item;
                    return false;
                }
            });
            return tempArr;
        }

        return check();
    }());

    BW.appClientinfo = (function () { // 第三方 APP 的 clientId / clientUserId
        var defaultStr = {
            clientId: '11111',
            clientUserId: '',
            bindSwitch: false,
            OAuth: false,
            loginjrnno :''
        };
        var oauthSwitch = function (clientId, OAuth) { // 渠道编号 11111/11112 必须返回 false
            return !/\b(11111|11112)\b/.test(clientId) && OAuth;
        };
        return {
            get: function () {
                return $.extend({}, defaultStr, store.session(BW.STORE_APPCLIENTINFO));
            },
            set: function (data) {
                var tmp;
                if (data.clientId === '') {
                    throw new Error('clientId 不允许为空');
                }
                if (data.OAuth && $.type(data.OAuth) !== 'boolean') {
                    throw new Error('OAuth 只允许为 boolean 值');
                }
                tmp = $.extend({}, defaultStr, store.session(BW.STORE_APPCLIENTINFO), data);
                tmp.bindSwitch = oauthSwitch(tmp.clientId, tmp.OAuth);
                store.session(BW.STORE_APPCLIENTINFO, tmp);
                Base.clientId = tmp.clientId;
            },
            del: function () {
                store.session.remove(BW.STORE_APPCLIENTINFO);
                this.set(defaultStr);
            }
        }
    }());

    BW.uStore = function () { // 用户信息保存 localstorage or sessionstorage
        if (/\b(11111)\b/i.test(BW.appClientinfo.get().clientId)) {
            return store;
        }
        return store.session;
    };

    BW.Userinfo = (function () {  // 用户信息
        //var Userinfo = BW.uStore()(BW.STORE_USERINFO);
        return {
            get: function (name) {
                if (BW.uStore()(BW.STORE_USERINFO)) {
                    return BW.uStore()(BW.STORE_USERINFO)[name];
                }
            },
            getAll: function () {
                return BW.uStore()(BW.STORE_USERINFO);
            },
            set: function (name, str) {
                if (!name || !str) {
                    throw new Error('请输入需要设置键值对');
                }
                var Userinfo = BW.uStore()(BW.STORE_USERINFO);
                Userinfo[name] = str;
                BW.uStore()(BW.STORE_USERINFO, Userinfo);
            }
        }
    }());

    BW.tokenId = (function () { // tokenId / usrNo 获取与设置
        var defaultStr = {
            tokenId: '',
            usrNo: ''
        };
        return {
            get: function () {
                return $.extend({}, defaultStr, BW.uStore()(BW.STORE_USERTOKEN));
            },
            set: function (usertoken) {
                usertoken = $.extend({}, BW.uStore()(BW.STORE_USERTOKEN), usertoken);
                BW.uStore()(BW.STORE_USERTOKEN, usertoken);
                Base.tokenId = usertoken.tokenId ? usertoken.tokenId : '';
                Base.usrNo = usertoken.usrNo ? usertoken.usrNo : '';
            }
        }
    }());

    BW.sessionStore = (function () { // 设置页面本地缓存
        var checkName = function (name) {
            var page = {
                sCard: 'securityCard', // 安全卡
                msg: 'msg', //短信验证
                transferOut: 'transferOut', // 转出
                transferIn: 'transferIn', // 转入
                assets: 'assets', // 收益
                result: 'resultPage', // 提示页
                detail: 'detailPage', // 详情页
                detailtips: 'detailtips', // 公共协议页面
                quesInfo: 'quesInfo',     //密保问题信息
                resetpwd: 'resetpwd',      //忘记密码页面
                fundIn: 'fundIn',         //基金转入页面
                fundOut: 'fundOut',         //基金转出页面
                dynPro: 'dynPro',           //动态协议
                obj: 'obj',
                appClientinfo: 'appClientinfo',
                ms:'ms',
                xy:'xy'
            };
            if (!page[name]) {
                throw new Error('name 参数错误');
            }

            return page[name];
        }, checkStr = function (str) {
            if (!$.isPlainObject(str) && $.trim(str) !== '') {
                throw new Error('str 参数不为对象');
            }
            return str;
        }, session_storage = store.session;

        return {
            get: function (name) {
                return session_storage(checkName(name));
            },
            set: function (name, str) {
                var bakStr = this.get(name),
                    tempStr;

                tempStr = str === '' ? str : (bakStr ? BW.addObject(checkStr(str), bakStr) : str);

                session_storage(checkName(name), checkStr(tempStr));
            },
            del: function (name) {
                return session_storage.remove(checkName(name));
            },
            delObj: function (key, value) {
                var obj = session_storage(checkName(key));
                delete obj[value];
                return BW.sessionStore.set(key, obj);
            }
        }
    }());

    // TODO:  公共后退按钮
    BW.backBtnAct = (function () {
        function init() {
            var $backBtn = $('.bw-head-comm .back-btn');
            if ($backBtn.length) {
                var localURI = new Uri(location.href),
                    gotoURI,
                    pathURI = localURI.path();
                // 增加goto参数的判断
                $.each(BW.gotoFilter, function (index, value, array) {
                    if (value == localURI.getQueryParamValue('goto')) {
                        gotoURI = localURI.getQueryParamValue('goto')
                    }
                });

                $backBtn.attr('href', (gotoURI ? gotoURI : '###')).on('click', function () {
                    //如果从和定期点后退按钮, 去除模拟点击事件
                    BW.sessionStore.set('detail', {'regular_Detail': '0'});
                    if (!gotoURI || pathURI.indexOf('login.html') !== -1) {
                        window.history.back();
                        return false;
                    }
                });
            }
        }

        init();
    }());

    BW.tpLink = (function () { // 公共协议跳转
        // <a class="bw-tpLink" href="detail_tips.html" data-url="http://xxx.com/1.html" data-title="协议标题">产品详情</a>
        function init() {
            var $tpLink = $('.bw-tpLink');
            $tpLink.click(function () {
                var $this = $(this),
                    url = $this.data('url'),
                    title = $this.data('title') !== '' ? $this.data('title') : $this.text();
                if (!url || url === '') {
                    return false
                }
                BW.sessionStore.set('detailtips', {url: url, title: title});
            });
        }

        init();
    }());

    // 百度统计
    var _hmt = _hmt || [];
    BW.tongji = (function () {
        _hmt.push(['_setCustomVar', 1, 'channel', BW.appClientinfo.get().clientId, 2]);
        head.js('//hm.baidu.com/hm.js?8d71adb46019ad40f9509e6496a2f03a', function () {
        });
    }());

    win._hmt = _hmt;

    win.BW = BW;

    /*2016.3.24 YSW 新增地理位置登记*/
    //获取地理位置
    BW.UserLocation = (function (g) {
        var posiData = {
            error: "1",      //是否拒绝标志   0： 允许   1: 拒绝
            longItude: "",    //经度
            latItude: "",    //纬度
            cityNm: "",      //市名
            provNm: ""       //省名
        };
        var loadApi = function () {
            var loadDtd = $.Deferred(),
                BMapFlg = false;   //是否加载百度API
            if (typeof BMap !== "undefined") {    //判断百度API是否加载成功
                BMapFlg = true;
                return loadDtd.resolve(BMapFlg);
            } else {
                // zuohx  更新ak 2017年5月15日21:20:02.
                // 必须先加载这个，否则会报跨域错误
                head.js("//api.map.baidu.com/api?v=2.0&ak=0MU0VrFd1c4ped1EQeg9LGeoWkf6DoCF&s=1", function () {
                });
                head.js("//api.map.baidu.com/getscript?v=2.0&ak=0MU0VrFd1c4ped1EQeg9LGeoWkf6DoCF&services=&t=20160310104956", function () {
                    BMapFlg = true;
                    return loadDtd.resolve(BMapFlg);
                });
                // head.js("//api.map.baidu.com/api?v=2.0&ak=ddGZ793rx2IOTWdPQyMETIiK&s=1", function () {
                // });
                // head.js("//api.map.baidu.com/getscript?v=2.0&ak=ddGZ793rx2IOTWdPQyMETIiK&services=&t=20160310104956", function () {
                //     BMapFlg = true;
                //     return loadDtd.resolve(BMapFlg);
                // });
            }
            return loadDtd.promise();
        };

        //终端位置信息登记接口
        var positionRegister = function (oprData, posiData) {
            if (!oprData.oprTyp) {
                BW.Toast('操作类型为空');
                return;
            }
            var data = {
                oprTyp: oprData.oprTyp,            //操作类型
                longItude: posiData.longItude,     //经度
                latItude: posiData.latItude,           //纬度
                cityNm: posiData.cityNm,               //市名
                provNm: posiData.provNm,               //省名
                ordTyp: oprData.ordTyp ? oprData.ordTyp : '',  //订单类型  操作类型为2时有值
                ordNo: oprData.ordNo ? oprData.ordNo : ''    //订单号
            }, api = globalConfig.httpPath + 'usr/urm/v1/positionRegister.do', posiDtd = $.Deferred();
            $.ajax({
                url: api,
                data: BW_API.reqEnjson(data),
                contentType: 'application/json',
                dataType: 'json',
                type: 'post',
                timeout: globalConfig.timeout,
                global: true,
                beforeSend: function () {
                }
            }).done(function (ajaxData, status, xhr) {
                var result = BW_API.resDejson(ajaxData);
                if (result.rspCd === '00000') {
                    console.log('终端位置信息登记成功');
                } else if (result.rspCd == 'FUN03157') {
                    readUserInfo.clearLoginCache();
                } else {
                    console.log(result.rspInf);
                }
                return posiDtd.resolve();
            }).fail(function (XMLHttpRequest, textStatus, errorThrown) {
                return posiDtd.reject();
            });
            return posiDtd.promise();
        };

        var getAuth = function () {  //获取权限
            var authDtd = $.Deferred();
            if (BW_isAPP.iOS) {   //如果在IOS客户端中，则由APP本身提供经纬度
                posiData = getIosLocation();    //取出IOS客户端返回的位置信息 getIosLocation():方法由客户端注入
                posiData = JSON.parse(posiData);    //转换成JSON对象
                return authDtd.resolve();
            } else if (BW_isAPP.Android && typeof(sys) !== 'undefined' && typeof(sys.getAndroidPosi) === 'function') {   //在安卓客户端中
                posiData = sys.getAndroidPosi();   //取出Android客户端返回的信息
                console.log(posiData);
                posiData = JSON.parse(posiData);    //转换成JSON对象
                if (posiData.longItude && posiData.longItude !== '') {   //如果返回的经纬度不为空，则表示用户允许
                    console.log('Android用户允许');
                    posiData.error = '0';
                } else {
                    console.log('Android用户拒绝');
                    posiData.error = '1';       //为空则表示用户拒绝
                }
                return authDtd.resolve();
            } else {       //不在客户端，需要H5获取地理位置
                if (navigator.geolocation) {
                    var location_timeout = setTimeout(geolocFail, 3200);
                    navigator.geolocation.getCurrentPosition(onSuccess, onError, {
                        //options参数配置
                        enableHighAccuracy: false,//boolean 是否要求高精度的地理信息
                        timeout: 3000,
                        maximumAge: 3000
                    });
                } else {
                    //不支持地理位置定位
                    geolocFail();
                }
            }

            //定位成功时
            function onSuccess(position) {
                clearTimeout(location_timeout);
                posiData.error = '0';
                return authDtd.resolve();
            }

            //定位失败时
            function onError(error) {
                clearTimeout(location_timeout);
                console.log('定位失败标志：' + error.code);
                if (error.code == error.PERMISSION_DENIED) { // console.log('位置共享服务被拒绝');
                    posiData.error = '1';
                } else {
                    posiData.error = '0';
                }
                //H5原生获取地理位置信息错误码：
                //error.PERMISSION_DENIED: 1   您拒绝了使用位置共享服务
                // POSITION_UNAVAILABLE:  2  无法提供位置服务
                // error.TIMEOUT :   3   获取位置信息连接超时
                return authDtd.reject();
            }

            //失败状态
            function geolocFail() {
                return authDtd.reject();
            }

            return authDtd.promise();
        };
        var getCurrentPosition = function () {    //获取经纬度
            var curDtd = $.Deferred();
            var location_timeout = setTimeout(geolocFail, 5200);   //定时器，防止geolocation方法卡死JS
            var geolocation = new BMap.Geolocation();
            geolocation.getCurrentPosition(function (r) {
                clearTimeout(location_timeout);   //清除计时器
                var errorCode = this.getStatus();
                if (errorCode == BMAP_STATUS_SUCCESS) {   //定位成功
                    var longItude = r.point.lng;//经度
                    var latItude = r.point.lat;  //纬度
                    posiData.longItude = longItude.toString().substr(0, 50);
                    posiData.latItude = latItude.toString().substr(0, 50);
                    return curDtd.resolve();
                } else {   // 定位失败
                    if (errorCode == BMAP_STATUS_PERMISSION_DENIED) {  //没有权限,地理位置服务被拒绝
                        posiData.error = '1';
                    }
                    return curDtd.reject();
                    //关于状态码
                    //BMAP_STATUS_SUCCESS   检索成功。对应数值“0”。
                    //BMAP_STATUS_CITY_LIST 城市列表。对应数值“1”。
                    //BMAP_STATUS_UNKNOWN_LOCATION  位置结果未知。对应数值“2”。
                    //BMAP_STATUS_UNKNOWN_ROUTE 导航结果未知。对应数值“3”。
                    //BMAP_STATUS_INVALID_KEY   非法密钥。对应数值“4”。
                    //BMAP_STATUS_INVALID_REQUEST   非法请求。对应数值“5”。
                    //BMAP_STATUS_PERMISSION_DENIED 没有权限。对应数值“6”。(自 1.1 新增)
                    //BMAP_STATUS_SERVICE_UNAVAILABLE   服务不可用。对应数值“7”。(自 1.1 新增)
                    //BMAP_STATUS_TIMEOUT   超时。对应数值“8”。(自 1.1 新增)
                }
            }, {enableHighAccuracy: true})

            //失败状态
            function geolocFail() {
                return curDtd.reject();
            }

            return curDtd.promise();
        }

        var getAdd = function (data) {    //根据经纬度获取城市信息
            var getDtd = $.Deferred();
            var locaAdd_timeout = setTimeout(geolocFail, 3200);   //定时器，防止geolocation方法卡死JS
            var point = new BMap.Point(data.longItude, data.latItude);   //传入经纬度
            var gc = new BMap.Geocoder();
            gc.getLocation(point, function (rs) {     //根据经纬度获取城市信息
                clearTimeout(locaAdd_timeout);   //清除计时器
                var addComp = rs.addressComponents;
                posiData.cityNm = addComp.city;      //城市名
                posiData.provNm = addComp.province;  //省名
                console.log(posiData.cityNm + posiData.provNm);
                return getDtd.resolve();
            });
            //失败状态
            function geolocFail() {
                return getDtd.reject();
            }

            return getDtd.promise();
        };


        //初始化终端位置信息
        var init = function () {
            var dtd = $.Deferred();
            //百度封装的H5获取经纬度方法监听不到用户的拒绝行为，所以需要用原生的方法监听用户是否开放位置权限
            $.when(getAuth()).always(function () {     //获取权限
                console.log(posiData.error);
                if (posiData.error !== '1') {   //表示用户没有拒绝地理位置服务
                    $.when(loadApi()).always(function (BMapFlg) {
                        if (BMapFlg) {    //如果百度API加载成功了，就查询城市信息
                            if (BW_isAPP.iOS || BW_isAPP.Android) {   //如果在客户端中，则由APP本身提供经纬度
                                if (posiData.longItude && posiData.longItude !== "") {   //如果经纬度不为空
                                    $.when(getAdd(posiData)).always(function () {   //获取城市信息
                                        return dtd.resolve();       //表示位置信息获取成功，可以结束异步控制
                                    })
                                } else {
                                    return dtd.reject();
                                }
                            } else {   //调用百度API获取经纬度
                                $.when(getCurrentPosition()).done(function () {     //获取经纬度
                                    $.when(getAdd(posiData)).always(function () {     //获取城市信息
                                        return dtd.resolve();
                                    })
                                }).fail(function () {
                                    return dtd.reject();
                                })
                            }
                        } else {       //如果加载失败 则不用查询地理位置信息
                            clearTimeout(location_timeout);
                            return dtd.resolve();
                        }
                    })
                } else {
                    console.log('地理位置服务被拒绝');
                    return dtd.reject();
                }

            });

            return dtd.promise();
        };
        //获取位置信息
        var getLocation = function (callback) {
            $.when(init()).always(function () {
                callback && callback();
            })
        };

        // 获取地理位置
        var getLocal = function (callback) {
            //百度封装的H5获取经纬度方法监听不到用户的拒绝行为，所以需要用原生的方法监听用户是否开放位置权限
            // $.when(getAuth()).always(function () {
            //     console.log(posiData.error);
            //     if (posiData.error !== '1') {   //表示用户没有拒绝地理位置服务
                    $.when(loadApi()).always(function (BMapFlg) {
                        if (BMapFlg) {    //如果百度API加载成功了，就查询城市信息
                            if (BW_isAPP.iOS || BW_isAPP.Android) {   //如果在客户端中，则由APP本身提供经纬度
                                if (posiData.longItude && posiData.longItude !== "") {   //如果经纬度不为空
                                    $.when(getAdd(posiData)).always(function () {   //获取城市信息
                                        callback && callback(posiData);
                                    })
                                }
                            } else {   //调用百度API获取经纬度
                                $.when(getCurrentPosition()).done(function () {     //获取经纬度
                                    $.when(getAdd(posiData)).always(function () {     //获取城市信息
                                        callback && callback(posiData);
                                    })
                                })
                            }
                        }
                    })
            //     } else {
            //         console.log('地理位置服务被拒绝');
            //         callback && callback('地理位置服务被拒绝');
            //     }
            // });


        };
        return {
            loadApi: loadApi,
            init: init,
            getLocal: getLocal,
            //对外返回登记终端位置信息方法，并且提供回调函数
            reg: function (oprTyp, callback) {   //oprTyp:操作类型 1.登录  2.下单 3.支付
                getLocation(function () {
                    if (posiData.error !== '1') {    //用户没有点击拒绝
                        $.when(positionRegister(oprTyp, posiData)).always(function () {
                            callback && callback();
                        });
                    } else {
                        callback && callback();
                    }
                });
            }
        }
    }());
}(window));
