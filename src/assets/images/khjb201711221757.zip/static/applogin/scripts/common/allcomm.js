/**
 * [加载公共模块]
 */
var ALLCOMM = (function (g, win, undefined) {
  "use strict";

  var makeDeferred = $.Deferred();

  head.js(
    "static/applogin/scripts/common/store2.min.js" + g.cdnFiletime,
    "static/applogin/scripts/common/URI.min.js" + g.cdnFiletime,
    "static/applogin/scripts/common/zui.min.js" + g.cdnFiletime,
    "static/applogin/scripts/common/appCommPlugin.js" + g.cdnFiletime,
    "static/applogin/scripts/common/bwCommon.js" + g.cdnFiletime,
    "static/applogin/scripts/common/xxBase.js" + g.cdnFiletime,
    "static/applogin/scripts/common/loginCacheModel.js" + g.cdnFiletime,
    function () {
      // if (BW.useSkin && BW.useSkin.fileuri !== '') {
      //     // 自动添加样式
      //     head.js(BW.useSkin.fileuri + g.cdnFiletime, function(){
      //         makeDeferred.resolve();
      //     });
      // }else{
      makeDeferred.resolve();
      // }
    });
  return {
    LOAD: function () {
      return makeDeferred.promise();
    }
  }
}(globalConfig, window));
