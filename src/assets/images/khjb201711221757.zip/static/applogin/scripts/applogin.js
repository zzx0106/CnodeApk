(function (g, win) {

    "use strict";

    var uriConfig = function () {
        if (!(this instanceof uriConfig)) {
            return new uriConfig();
        }

        this.userid = '';
        this.token = '';
        this.clientid = '';
        this.loginjrnno = '';//用户流水号
    };

    uriConfig.prototype = {
        get: function () {
            var localURI = new Uri(location.href);
            this.clientid = localURI.getQueryParamValue('clientid') || ''; // 第三方应用 Appid
            this.userid = localURI.getQueryParamValue('userid') || ''; // 第三方应用用户 ID
            this.token = localURI.getQueryParamValue('token') || ''; // 第三方应用已登录 Token
            this.loginjrnno = localURI.getQueryParamValue('loginjrnno') || ''; //第三方应用用户流水号
        }
    };

    var clientidComm = function () {
        if (!(this instanceof clientidComm)) {
            return new clientidComm();
        }
    };

    //优化江苏用户点击两次返回的问题
    var appClientinfo = BW.sessionStore.get('appClientinfo');
    // 06642 掌厅生活      35876 掌厅生活    80974 V网通免登       15961 V网通异常处理     69794业务短信 邮箱推广   98716微信分享 支付宝江苏移动生活号  19346 掌厅分享 自传播   18353 掌厅免登  45779 掌厅异常处理
    if(document.referrer.indexOf('cmf.cmpay.com') == -1){
        var path=document.referrer;
        if(path){
            window.sessionStorage.setItem('referrer',path);
        }
    }
    if (appClientinfo && '06642'===appClientinfo.clientId||appClientinfo && '18353'===appClientinfo.clientId||appClientinfo && '35876'===appClientinfo.clientId||appClientinfo && '80974'===appClientinfo.clientId||appClientinfo && '15961'===appClientinfo.clientId||appClientinfo && '69794'===appClientinfo.clientId||appClientinfo && '98716'===appClientinfo.clientId||appClientinfo && '19346'===appClientinfo.clientId||appClientinfo && '18353'===appClientinfo.clientId||appClientinfo && '45779 '===appClientinfo.clientId){
        //     var back=function (){
        //         window.parent.parent.location.href='<c:url value="/biz/safemanage/enterpriseMain.jsp"/>';
        //     };
        //     window.setTimeout("back();",3000);   //3秒后自动跳转
        BW.sessionStore.del('appClientinfo');
        if(window.sessionStorage.getItem('referrer')){
            location.href=window.sessionStorage.getItem('referrer');
        }
    }

    clientidComm.prototype = {
        setClient: function (Clientid, ClientUserid, OAuth,loginjrnno) {
            readUserInfo.clearLoginCache('notjump'); // 清除本地登录信息缓存
            OAuth = OAuth === '1' ? true : false;
            BW.appClientinfo.set({
                clientId: Clientid,
                clientUserId: ClientUserid,
                OAuth: OAuth,
                loginjrnno :loginjrnno
            });
        },
        getStatus: function (Clientid, ClientUserid ,loginjrnno) {
            var self = this,
                data = {
                    clientId: Clientid
                },
                api = g.httpPath + 'usr/partner/v1/clientQry.do',
                deferred = $.Deferred();
            BW.appClientinfo.del();
            if (Clientid === "") {
                return deferred.reject('接口请求异常，clientid 为空');
            }
            $.ajax({
                url: api,
                data: BW_API.reqEnjson(data),
                contentType: 'application/json',
                dataType: 'json',
                type: 'post',
                timeout: g.timeout,
                global: true,
                beforeSend: function () {
                }
            }).done(function (ajaxData, status, xhr) {
                ajaxData = BW_API.resDejson(ajaxData);
                if (ajaxData.rspCd === '00000') {
                    if (ajaxData.clientIsLogin === '1' && ClientUserid === "") {
                        return deferred.reject('接口请求异常，userid 为空');
                    }
                    self.setClient(Clientid, ClientUserid, ajaxData.clientIsLogin,loginjrnno);
                    return deferred.resolve();
                } else {
                    return deferred.reject(ajaxData.rspInf);
                }
            }).fail(function (XMLHttpRequest, textStatus, errorThrown) {
            });
            return deferred.promise();
        },
        tokenLogin: function (ClientToken) {
            var deferred = $.Deferred();
            if (ClientToken) {
                BW.tokenId.set({
                    tokenId: ClientToken
                });
                readUserInfo.loginInit(function (data) {
                    if (data.rspCd === '00000') {
                        return deferred.resolve();
                    } else {
                        readUserInfo.clearLoginCache('notjump');
                        BW.appClientinfo.del();
                        if (data.rspCd === 'FUN03157') { //用户未登录
                            data.rspInf = '登录失败，请重新打开和聚宝应用';
                            BW.Toast(data.rspInf);
                        }
                        return deferred.reject();
                    }
                });
            } else {
                return deferred.resolve();
            }
            return deferred.promise();
        }
    };

    // var goto = function () {
    //     var wxFlg = new Uri(location.href).getQueryParamValue('forwardTyp'),
    //         gotoPage = 'index.html';
    //     switch (wxFlg) {
    //         case '1':
    //             gotoPage = 'index.html';
    //             break;
    //         case '2':
    //             gotoPage = 'assets.html';
    //             break;
    //         default :
    //             gotoPage = 'index.html';
    //     }
    //     location.replace(g.statichttpPath + gotoPage);
    // };

    var gotoIndex = function (clientid) {
        // TODO:*** 和掌厅渠道码
        if ('78301' === clientid) {
            location.href=g.statichttpPath + 'template/doubleActivities/doubleActivities.html';
        } else {
            location.href=g.statichttpPath + 'index.html';
        }
    };


    win.BW_TEST = {
        uriConfig: uriConfig,
        clientidComm: clientidComm
    };

    $(function () {
        //BW.hideLoadingPage();

        if (location.href.indexOf('test') !== -1) {
            return false;
        }

        var U_uriConfig = uriConfig(),
            U_clientidComm = clientidComm();

        U_uriConfig.get();
        U_clientidComm.getStatus(U_uriConfig.clientid, U_uriConfig.userid ,U_uriConfig.loginjrnno).then(function () {
            return U_clientidComm.tokenLogin(U_uriConfig.token);
        }, function (data) {
            BW.Toast(data);
        }).then(function () {
            // goto();
            gotoIndex(U_uriConfig.clientid);
        });
    });
}(globalConfig, window));
