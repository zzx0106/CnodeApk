!function (win, $) {
  var config = {
    state: false,
    dom: {
      $body: $("body"),
      $iframe: null
    },
    CALLBACK: {
      success: "PW_SUCCESS_CALLBACK",
      failure: "PW_FAILURE_CALLBACK",
      close: "PW_CLOSE_CALLBACK"
    },
    DEF: $.Deferred(),
    path: 'https://uat.cmpay.com'
  }, SDK = {};

  SDK.version = "1.0";
  SDK.view = {
    template: function (i) {
      var e =
        ['<div id="passport-iframe-con" class="passport-iframe-con" style="display:none">',
          '<iframe id="login-passport-frame" height="100%" scrolling="no" width="100%" frameborder="0" style="border:none;" src="' + i + '"></iframe>',
          "</div>"];
      return e.join("")
    },
    makePop: function (i) {
      var e = config.path + "/info/pw-control/index.html", o = "";
      return e += "?" + SDK.util.serialize(i), o = SDK.view.template(e)
    },
    init: function (userConfig) {
      if (config.DEF.state() !== 'resolved') {
        userConfig = $.extend(true, {
          r: Math.random() // 避免页面缓存
        }, userConfig);
        var dom = SDK.view.makePop(userConfig);
        config.dom.$iframe = $(dom);
        config.dom.$body.append(config.dom.$iframe);
        config.dom.$iframe.find('iframe').load(function () {
          config.DEF.resolve();
        });
      }

      return config.DEF.promise();
    }
  };
  SDK.util = {
    serialize: function (i) {
      var e = ""
        , o = [];
      try {
        for (var t in i)
          o.push(t + "=" + i[t]);
        e = o.join("&")
      } catch (n) {
      }
      return e
    }
  };
  SDK.MESSAGE = {
    send: function (data) {
      if (config.DEF.state() === 'pending') {
        throw new Error('iframe 未加载完毕，暂无法通讯。');
      }
      if (!$.isPlainObject(data)) {
        throw new Error('传值必须为 object');
      }
      config.dom.$iframe.find('iframe')[0].contentWindow.postMessage(data, config.path);
    }
  };

  win.PassWordSDK = {
    init: SDK.view.init,
    MESSAGE: SDK.MESSAGE
  };
}(window, jQuery);
