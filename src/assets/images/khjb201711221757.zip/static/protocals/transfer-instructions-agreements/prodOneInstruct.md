### 和聚宝资金转入说明;

>在资金转入后，份额实时到账。15:00前转入的资金(以支付成功时间为准)，第二个工作日开始计算收益，收益将在计算收>益后的次日发放，15:00后转入资金顺延一个工作日发放收益。双休日及国家法定假期转入的资金，基金公司将在下一个工>作日确认份额，确认后次日发放收益。
>例：周四15:00后转入的资金，基金公司下周一完成份额确认。

<table width="100%" class="t-table">
  <thead>
    <tr>
      <th valign="center">转入时间</th>
      <th valign="center">首次收益显示时间</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td valign="center">周一15:00至周二15:00</td>
      <td valign="center">周四</td>
    </tr>
    <tr>
      <td valign="center">周二15:00至周三15:00</td>
      <td valign="center">周五</td>
    </tr>
    <tr>
      <td valign="center">周三15:00至周四15:00</td>
      <td valign="center">周六</td>
    </tr>
    <tr>
      <td valign="center">周四15:00至周五15:00</td>
      <td valign="center">下周二</td>
    </tr>
    <tr>
      <td valign="center">周五15:00至下周一15:00</td>
      <td valign="center">下周三</td>
    </tr>
  </tbody>
</table>
